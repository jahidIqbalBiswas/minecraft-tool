//preloader
window.addEventListener('load', function() {
    var preloader = document.querySelector("#preloader");
    preloader.classList.add("preloaderOpen");
});